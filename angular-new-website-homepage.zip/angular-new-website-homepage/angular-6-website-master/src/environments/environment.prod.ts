export const environment = {
  production: true,
  apiUrl: 'api/posts',
  emailUrl: 'https://localhost/api/contact.php'
};
